# Sophon borrowings and provenance ledger

> Normative compliance record. Copied, translated, or structurally adapted
> work must be registered here. Entries record provenance and do not imply
> implementation status. License texts and copyright notices are in
> [`THIRD_PARTY_NOTICES`](../THIRD_PARTY_NOTICES).

## Reference sources

| Source | License | Pin / provenance | Use and boundary |
|---|---|---|---|
| [`zeronsh/comet`](https://github.com/zeronsh/comet) | MIT | `fb22e269ac57331ee7aa4a9673530acf3299a886`; historical checkout `~/origingame-refs/comet` | UI source, visual language, and microinteraction reference; no engine, RPC, account, or update authority |
| [`pingdotgg/t3code`](https://github.com/pingdotgg/t3code) | MIT | `a041981276b4c789fed8132e3b8a320749bf25e8`; historical checkout `~/origingame-refs/t3code` | Orchestration, checkpoint, and interaction reference; not a visual source and not a permission model |
| [`fran0220/grok-build-sdk`](https://github.com/fran0220/grok-build-sdk) | Apache-2.0 | SDK v0.1.0 pin `e4538048cb752a631bf2c63e377ba99f0fa3f3bd`; historical fork baseline `c9e97f4b70d0c488f111f79db658d8c5ef410a5c`; upstream SOURCE_REV `3e620a76a5f374ce644dc7c87f7e990c68348218`; public snapshot `afbc0fb710320c7add294c2106d447ecc3e3af2e` | Sophon's only runtime source, linked in-process. Historical ACP/CLI details are SDK lineage, not a Sophon compatibility surface |
| [`fran0220/gpui-kit`](https://github.com/fran0220/gpui-kit) | MIT | current pin `b4048997aec14076c7a4084f5a0c63f7a2ed6d93`; GPUI integration pin `f9e7bd617940af337f34f0c5d90e4a83846b6ebe` | Product-neutral production components and dev-only semantic/visual testkit; no product surface migrated at this pin |
| `zed-industries/zed` and the sibling GPUI fork | Apache-2.0 | base `a6a23c7b80a5cefa0487b7856335be89ace7e483`; current pin `f9e7bd617940af337f34f0c5d90e4a83846b6ebe`; required checkout `../origingame-refs/zed-fork` | GPUI, `gpui_platform`, and `gpui_tokio` path dependencies; gpui-kit's exact Git source is patched to the same sibling GPUI package |

Historical local checkout names are retained only to make source and license
provenance reproducible. They are not build inputs except for the required
GPUI sibling path above.

## GPUI patch provenance

| ID | Source and revision | Purpose / current boundary |
|---|---|---|
| P01 | Retired vendored GPUI 0.2.2, `69e2130295c2649963eb639fc70b4f2ee8ea1624` | Historical input only; public event dispatch made the wrapper unnecessary |
| P02 | `wingleeio/zed` `a6c1ad501f90c9437d2553bde691958f150364c5` | Text-wrap fixes |
| P03 | `wingleeio/zed` commits `f4000415b9`, `ade919583d` | EdgeFade, BackdropBlur, and macOS glass adaptation |
| P04 | Zed PR #61945 / `huacnlee:gpui-webview-overlay`, `20a699acac7b5bceea8e8fe6ba257a61ad47fb09` | Native-surface composition primitives retained in the fork; no current WebView product claim |
| P05 | `wry` 0.54.3 (MIT OR Apache-2.0) | Historical deleted WebView2 implementation reference only; no current landing |

## Comet-derived UI

| ID | Borrowing | Current landing | Method and boundary |
|---|---|---|---|
| C01 | Theme, Geist fonts, icons, motion, loaders, frost, EdgeFade, popover/dialog primitives | `sophon-shell::{theme,motion,motion_math,loaders,frost,edge_fade,popover,icons}` and `assets/` | Source port. `comet-proto` is not linked. The measurement knob is `SOPHON_MOTION_SCALE` |
| C02 | Shell, rail, spaces, tabs, window chrome, menus | `sophon-shell::{shell,rail,app_menus}` | Source port split by rendering surface; reads Sophon view models and owns only visual transient state |
| C03 | Transcript, Markdown, tool/activity rows, attachments, composer, pickers | `sophon-shell::{transcript,markdown,attachments,composer,pickers}` | Source port against Sophon view models; no Comet engine/RPC authority |
| C04 | Changes/diff presentation | `sophon-shell::changes` | Source port fed by host snapshots; preparing/clean/list/error states remain reachable |
| C05 | Terminal emulator, panel, view | `sophon-shell::terminal` | Source port; process lifecycle belongs to Sophon rather than Comet |
| C06 | Settings layout, widgets, and native menus | `sophon-shell::{settings,app_menus}` | Source port; only truthful Sophon-supported settings are presented |

Font and icon licenses and attribution are also recorded beside the assets in
`assets/fonts/SOURCE.md` and `crates/sophon-shell/assets/SOURCE.md`.

## t3code-derived mechanisms

| ID | Borrowing | Current landing | Method / boundary |
|---|---|---|---|
| T01–T06 | Typed RPC vocabulary; single-worker event engine; receipts; transactions; decider/projector split; drainable worker | `sophon-rpc`, `sophon-core`, `sophon-store` | Structural translation; t3code's per-method authorization scopes were not adopted |
| T07–T08 | Buffered assistant delivery and separated runtime-command reactor responsibilities | `sophon-core` | Structural translation; approval boundaries were not adopted |
| T10–T11 | Grok driver/ACP mapping and stdio framing | Deleted historical implementation | Provenance only; current SDK is linked in-process and ACP is not a Sophon seam |
| T12–T13 | Connection supervisor separation and startup command gate | `sophon-client`, `sophon-core`, `sophon-app` | Structural translation |
| T15–T21 | Keybindings, palettes, thread defaults, turn settlement, timeline, structured input, composer | `sophon-client`, `sophon-shell` | Interaction adaptation; historical approval UI is deleted |
| T22–T33 | Diffs, terminal drawer, navigation, settings, host Git checkpoints, repository acquisition | `sophon-shell`, `sophon-ui`, `sophon-vcs`, `sophon-app` | Interaction/architecture adaptation; no provider registry, relay, mobile stack, or copied visual styling |

The checkpoint architecture uses an independent temporary Git index, hidden
per-thread/per-turn refs, turn-settlement capture, diff, and restore. Runtime
conversation state coordinates with, but does not own, host Git restoration.

## Zed process borrowing

| ID | Borrowing | Landing | Boundary |
|---|---|---|---|
| Z01 | Windows Job Object `KILL_ON_JOB_CLOSE` process-tree ownership from `crates/util/src/process.rs` | `sophon-process` | Safe RAII lifecycle for user-opened child processes; not a runtime-tool sandbox or authorization boundary |

## grok-build-sdk lineage

The public SDK is the current source. These entries retain legally and
technically useful lineage without claiming deleted integration code exists:

| ID | Historical source fact | Current boundary |
|---|---|---|
| G01–G03 | Apache-2.0 ACP/session/model plumbing in upstream Grok Build | SDK internal implementation; Sophon has no direct ACP integration |
| G04–G07 | Historical question callbacks, plan/subagent states, CLI config, and stdio entry points | Historical reference only; no ambient CLI credentials or external runtime executable |
| G08–G11 | Historical rewind, context, headless, and Git envelopes | Host checkpoint authority is `sophon-vcs`; runtime is in-process |

## Sophon-owned surfaces

The interruption banner, scoped diff controls, diff keyboard navigation,
preparing watchdog, staged/untracked tally, and rewind UI have no direct
upstream implementation. Their current landings are respectively
`sophon-shell::{failure,changes,rewind}`, with host projections in
`sophon-app`. They reuse registered Comet visual primitives but their product
behavior is Sophon-owned.

## Tokens

`tokens/tokens.json` contains the concrete product token documents.
`sophon-theme` parses them through the pinned gpui-kit token contract and maps
the registered Comet visual language without generating a second Rust schema
or maintaining a legacy palette.
