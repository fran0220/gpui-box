//! Sophon-owned themes parsed and adapted by gpui-kit.
//!
//! `../../tokens/tokens.json` is the concrete product authority. This crate
//! deliberately does not mirror gpui-kit's token schema: every embedded theme
//! must pass the pinned [`TokenDocument::parse`] implementation and contrast
//! gate before it can enter the application's one [`ThemeRegistry`].

#![doc(html_no_source)]

use std::sync::OnceLock;

use gpui_kit::theme::ThemeRegistry;
use gpui_kit::tokens::{TokenDocument, contrast};

pub use gpui_kit::theme::{Appearance, Density};

/// Stable ids used by preferences and the gpui-kit registry.
pub const DARK_THEME_ID: &str = "sophon-dark";
pub const LIGHT_THEME_ID: &str = "sophon-light";

/// The current product preference. The shell remains dark until a real
/// appearance preference is restored; shipping a light document does not
/// silently reintroduce the removed preference.
pub const DEFAULT_APPEARANCE: Appearance = Appearance::Dark;
/// Sophon's current information-density preference.
pub const DEFAULT_DENSITY: Density = Density::Comfortable;

const TOKEN_DOCUMENTS_JSON: &str = include_str!("../../../tokens/tokens.json");

/// Both concrete product documents, parsed once from Sophon's token source.
pub fn documents() -> &'static [TokenDocument; 2] {
    static DOCUMENTS: OnceLock<[TokenDocument; 2]> = OnceLock::new();
    DOCUMENTS.get_or_init(|| {
        parse_documents().unwrap_or_else(|error| panic!("Sophon theme tokens are invalid: {error}"))
    })
}

/// The concrete document selected by the product appearance preference.
pub fn document(appearance: Appearance) -> &'static TokenDocument {
    match appearance {
        Appearance::Dark => &documents()[0],
        Appearance::Light => &documents()[1],
    }
}

/// Registers or replaces both Sophon themes, selects the requested appearance,
/// and applies the product-owned density preference.
pub fn activate(
    registry: &mut ThemeRegistry,
    appearance: Appearance,
    density: Density,
) -> Result<(), String> {
    for document in documents() {
        registry.register(document.clone());
    }
    registry.set_density(density);
    let id = match appearance {
        Appearance::Dark => DARK_THEME_ID,
        Appearance::Light => LIGHT_THEME_ID,
    };
    if !registry.activate(id) {
        return Err(format!(
            "registered Sophon theme `{id}` could not be activated"
        ));
    }
    Ok(())
}

fn parse_documents() -> Result<[TokenDocument; 2], String> {
    let fixture: serde_json::Value = serde_json::from_str(TOKEN_DOCUMENTS_JSON)
        .map_err(|error| format!("tokens/tokens.json is not valid JSON: {error}"))?;
    let dark = parse_document("dark", &fixture["dark"], DARK_THEME_ID, Appearance::Dark)?;
    let light = parse_document(
        "light",
        &fixture["light"],
        LIGHT_THEME_ID,
        Appearance::Light,
    )?;
    Ok([dark, light])
}

fn parse_document(
    fixture_key: &str,
    value: &serde_json::Value,
    expected_id: &str,
    expected_appearance: Appearance,
) -> Result<TokenDocument, String> {
    let json = serde_json::to_string(value)
        .map_err(|error| format!("could not read `{fixture_key}` theme: {error}"))?;
    let document = TokenDocument::parse(&json)
        .map_err(|error| format!("`{fixture_key}` does not parse as TokenDocument: {error}"))?;
    if document.meta.id != expected_id {
        return Err(format!(
            "`{fixture_key}` theme id is `{}`, expected `{expected_id}`",
            document.meta.id
        ));
    }
    if document.meta.appearance != expected_appearance {
        return Err(format!(
            "`{fixture_key}` theme appearance is {:?}, expected {expected_appearance:?}",
            document.meta.appearance
        ));
    }
    let failures = contrast::failures(&document);
    if !failures.is_empty() {
        return Err(format!(
            "`{fixture_key}` fails gpui-kit contrast checks: {failures:#?}"
        ));
    }
    Ok(document)
}

#[cfg(test)]
mod tests {
    use gpui_kit::theme::{Appearance, Density, ThemeRegistry};
    use gpui_kit::tokens::{
        Color, InteractiveColor, SemanticColor, Surface, TextTone, contrast, contrast_ratio, over,
    };

    use super::{DARK_THEME_ID, LIGHT_THEME_ID, activate, document, documents, parse_documents};

    fn color(hex: &str) -> Color {
        Color::parse("expected", hex).expect("test color")
    }

    #[test]
    fn sophon_dark_and_light_parse_and_pass_contrast() {
        let parsed = parse_documents().expect("both concrete Sophon TokenDocuments");
        assert_eq!(parsed[0].meta.id, DARK_THEME_ID);
        assert_eq!(parsed[1].meta.id, LIGHT_THEME_ID);
        for tokens in &parsed {
            assert!(
                contrast::failures(tokens).is_empty(),
                "{} failed contrast",
                tokens.meta.id
            );
        }
    }

    #[test]
    fn sophon_extensions_cover_sunken_text_and_the_real_accent_strong_treatment() {
        for tokens in documents() {
            let sunken = tokens.surface(Surface::Sunken);
            for (tone, minimum) in [
                (TextTone::Primary, 4.5),
                (TextTone::Muted, 4.5),
                (TextTone::Faint, 3.0),
            ] {
                let ratio = contrast_ratio(tokens.text(tone), sunken);
                assert!(
                    ratio >= minimum,
                    "{} {tone:?} on sunken is {ratio:.2}:1, below {minimum}:1",
                    tokens.meta.id
                );
            }

            // Changes' active whitespace toggle paints accent at 16% over the
            // canvas and then uses accentStrong for its label. b404 defines
            // accentStrong at the 3:1 emphasis floor; this explicit product
            // check covers the real composite that its generic report omits.
            let mut fill = tokens.semantic(SemanticColor::Accent);
            fill.alpha = 0.16;
            let background = over(fill, tokens.surface(Surface::Canvas));
            let ratio = contrast_ratio(tokens.semantic(SemanticColor::AccentStrong), background);
            assert!(
                ratio >= 3.0,
                "{} accentStrong on the active accent wash is {ratio:.2}:1, below 3:1",
                tokens.meta.id
            );
        }

        // Dark is the actual product appearance in Wave 1. Its 11px Changes
        // label is historical paint and therefore remains below the 4.5:1
        // body-text target, but it must not regress below the measured 3.7:1
        // baseline while native visual parity is being established.
        let dark = document(super::DEFAULT_APPEARANCE);
        let mut fill = dark.semantic(SemanticColor::Accent);
        fill.alpha = 0.16;
        let background = over(fill, dark.surface(Surface::Canvas));
        let ratio = contrast_ratio(dark.semantic(SemanticColor::AccentStrong), background);
        assert!(
            ratio >= 3.7,
            "active dark accentStrong treatment regressed to {ratio:.2}:1"
        );
    }

    #[test]
    fn dark_document_preserves_every_active_shell_semantic_color() {
        let dark = document(Appearance::Dark);
        assert_eq!(dark.surface(Surface::Canvas), color("#060606"));
        assert_eq!(dark.surface(Surface::Panel), color("#0d0d0d"));
        assert_eq!(dark.surface(Surface::Raised), color("#1e1e1e"));
        assert_eq!(dark.surface(Surface::Overlay), color("#1e1e1e"));
        assert_eq!(dark.text(TextTone::Primary), color("#e5e5e5"));
        assert_eq!(dark.text(TextTone::Muted), color("#a1a1a1"));
        assert_eq!(dark.text(TextTone::Faint), color("#737373"));
        assert_eq!(
            dark.interactive(InteractiveColor::Hover),
            color("#ebebeb24")
        );
        assert_eq!(
            dark.interactive(InteractiveColor::Active),
            color("#ebebeb29")
        );
        assert_eq!(
            dark.interactive(InteractiveColor::Selected),
            color("#ebebeb24")
        );
        assert_eq!(
            dark.interactive(InteractiveColor::Hairline),
            color("#ffffff14")
        );
        assert_eq!(
            dark.interactive(InteractiveColor::HairlineStrong),
            color("#ffffff24")
        );
        assert_eq!(dark.semantic(SemanticColor::Accent), color("#7c86ff"));
        assert_eq!(dark.semantic(SemanticColor::AccentStrong), color("#615fff"));
        assert_eq!(dark.semantic(SemanticColor::Danger), color("#ff6467"));
        assert_eq!(dark.semantic(SemanticColor::Warning), color("#ffb900"));
        assert_eq!(dark.semantic(SemanticColor::Success), color("#00d492"));
        assert_eq!(
            Color::resolve(
                "color.palette.pink.working",
                "{pink.working}",
                &dark.color.palette,
            )
            .expect("working status color"),
            color("#fb64b6")
        );
        assert_eq!(
            dark.loader_gradient(),
            [color("#b6d3ef"), color("#edb185"), color("#f888a0")]
        );
    }

    #[test]
    fn registry_uses_sophon_ids_and_preserves_the_density_preference() {
        let mut registry = ThemeRegistry::new();
        activate(&mut registry, Appearance::Light, Density::Compact).expect("activate light");
        assert_eq!(registry.active().id, LIGHT_THEME_ID);
        assert_eq!(registry.active().appearance, Appearance::Light);
        assert_eq!(registry.density(), Density::Compact);
        assert!(registry.ids().iter().any(|id| id.as_ref() == DARK_THEME_ID));
        assert!(
            registry
                .ids()
                .iter()
                .any(|id| id.as_ref() == LIGHT_THEME_ID)
        );
        assert_eq!(documents().len(), 2);
    }
}
