//! What the window says it is showing, checked against what it drew.
//!
//! Every case here opens a real gpui window and reads the tree the frame
//! produced, because a tree assembled without a layout pass would prove nothing
//! about the two properties that matter: that a surface on screen is in it, and
//! that a surface which is not on screen is *absent* rather than present with
//! stale bounds.

use chrono::Utc;
use gpui::{App, AppContext as _, Entity, TestAppContext, VisualTestContext};

use crate::automation::{SurfaceTree, ids};
use crate::state::ShellState;
use crate::viewmodel::SessionFailure;

use super::Shell;

/// The same theme/bootstrap sequence as the composition root, minus menus that
/// a test window never asks the platform to display.
fn install(cx: &mut App) {
    gpui_kit::install(cx);
    crate::theme::Theme::install(cx);
    super::init(cx);
}

/// A shell over the fixture world in a window that really lays out.
fn open(cx: &mut TestAppContext) -> (Entity<ShellState>, Entity<Shell>, &mut VisualTestContext) {
    let now = Utc::now();
    // The same globals the product installs before its first frame: a window
    // drawn without them would panic on the theme rather than lay anything out.
    cx.update(install);
    let state = cx.update(|cx| cx.new(|_| crate::fixtures::shell_state(now)));
    let held = state.clone();
    let (shell, cx) = cx.add_window_view(move |_, cx| Shell::new(held, cx));
    (state, shell, cx)
}

/// Draws a frame and reads the tree it produced.
fn drawn(shell: &Entity<Shell>, cx: &mut VisualTestContext) -> SurfaceTree {
    cx.update(|window, _| window.refresh());
    cx.run_until_parked();
    shell.read_with(cx, |shell, _| shell.surface_tree())
}

#[gpui::test]
fn the_window_names_the_surfaces_it_drew(cx: &mut TestAppContext) {
    let (_state, shell, cx) = open(cx);
    let tree = drawn(&shell, cx);

    for id in [
        ids::ROOT,
        ids::SIDEBAR,
        ids::PROJECT_TAB_STRIP,
        ids::PROJECT_NEW,
        ids::SESSION_NEW,
        ids::COMPOSER,
        ids::COMPOSER_INPUT,
        ids::COMPOSER_SEND,
    ] {
        assert!(
            tree.contains(id),
            "{id} is on screen but not in the tree; the tree holds {:?}",
            tree.ids()
        );
    }
    assert!(
        !tree.contains("shell.nothing-like-this"),
        "the tree answered for an element nobody rendered"
    );
}

#[gpui::test]
fn every_session_row_is_named_after_the_session_it_shows(cx: &mut TestAppContext) {
    let (state, shell, cx) = open(cx);
    let expected: Vec<String> = state.read_with(cx, |state, _| {
        let selected = state
            .selected_space
            .as_deref()
            .expect("the fixture world has a selected Project");
        state
            .chats_in_space(selected)
            .into_iter()
            .map(|chat| ids::session_row(&chat.id))
            .collect()
    });
    assert!(!expected.is_empty(), "the fixture world has no sessions");

    let tree = drawn(&shell, cx);
    let drawn: Vec<String> = tree
        .under(ids::SESSION_ROW_PREFIX)
        .iter()
        .map(|node| node.id.clone())
        .collect();
    for id in &expected {
        assert!(
            drawn.contains(id),
            "{id} has a row but no id; drawn: {drawn:?}"
        );
    }
    assert!(
        !tree.contains(&ids::session_row("a-session-that-does-not-exist")),
        "the tree named a session the world does not have"
    );
    for node in tree.under(ids::SESSION_ROW_PREFIX) {
        assert!(node.visible, "{} is in the tree with no area", node.id);
    }
}

#[gpui::test]
fn every_project_is_a_titlebar_capsule_with_its_visible_name(cx: &mut TestAppContext) {
    let (state, shell, cx) = open(cx);
    let projects = state.read_with(cx, |state, _| {
        state
            .spaces
            .iter()
            .map(|project| (project.id.clone(), project.display_name().to_string()))
            .collect::<Vec<_>>()
    });

    let tree = drawn(&shell, cx);
    assert_eq!(
        tree.under(ids::PROJECT_TAB_PREFIX).len(),
        projects.len(),
        "the capsule strip is not the Project registry"
    );
    for (id, name) in projects {
        let node = tree.find(&ids::project_tab(&id)).unwrap_or_else(|| {
            panic!(
                "the Project has no titlebar capsule; tree: {:?}",
                tree.ids()
            )
        });
        assert_eq!(node.text.as_deref(), Some(name.as_str()));
    }
    assert!(
        tree.nodes
            .iter()
            .all(|node| !node.id.starts_with("shell.sidebar.space.")),
        "the old Project rail still duplicates the titlebar"
    );
}

#[gpui::test]
fn project_capsules_restore_their_own_session_and_filter_the_sidebar(cx: &mut TestAppContext) {
    let (state, shell, cx) = open(cx);
    let (first_project, first_session, other_project, other_sessions) =
        state.read_with(cx, |state, _| {
            let first_project = state.selected_space.clone().expect("selected Project");
            let first_session = state.selected_chat.clone().expect("selected Session");
            let other_project = state
                .spaces
                .iter()
                .find(|project| {
                    project.id != first_project && state.chats_in_space(&project.id).len() >= 2
                })
                .expect("a second fixture Project with two Sessions")
                .id
                .clone();
            let other_sessions = state
                .chats_in_space(&other_project)
                .into_iter()
                .map(|chat| chat.id.clone())
                .collect::<Vec<_>>();
            (first_project, first_session, other_project, other_sessions)
        });

    shell.update(cx, |shell, cx| {
        shell.activate_space(other_project.clone(), cx)
    });
    cx.run_until_parked();
    shell.update(cx, |shell, cx| {
        shell.select_chat(Some(other_sessions[1].clone()), cx)
    });
    cx.run_until_parked();
    shell.update(cx, |shell, cx| {
        shell.activate_space(first_project.clone(), cx)
    });
    cx.run_until_parked();
    state.read_with(cx, |state, _| {
        assert_eq!(state.selected_chat.as_deref(), Some(first_session.as_str()));
    });

    shell.update(cx, |shell, cx| {
        shell.activate_space(other_project.clone(), cx)
    });
    cx.run_until_parked();
    state.read_with(cx, |state, _| {
        assert_eq!(
            state.selected_chat.as_deref(),
            Some(other_sessions[1].as_str()),
            "the Project did not recover the Session left inside it"
        );
    });
    let tree = drawn(&shell, cx);
    assert!(
        tree.find(&ids::project_tab(&other_project))
            .is_some_and(|tab| tab.selected),
        "the active Project capsule is not selected"
    );
    let visible_sessions = tree
        .under(ids::SESSION_ROW_PREFIX)
        .iter()
        .map(|row| row.id.clone())
        .collect::<Vec<_>>();
    assert_eq!(
        visible_sessions,
        other_sessions
            .iter()
            .map(|session| ids::session_row(session))
            .collect::<Vec<_>>(),
        "the sidebar is not scoped to the active Project"
    );
}

#[gpui::test]
fn an_empty_project_never_leaks_another_projects_sessions(cx: &mut TestAppContext) {
    let (state, shell, cx) = open(cx);
    let empty_project = "space-notes";
    state.update(cx, |state, cx| {
        for chat in &mut state.chats {
            if chat.space_id.as_deref() == Some(empty_project) {
                chat.archived = true;
            }
        }
        state.select_space(Some(empty_project.into()));
        state.select_chat(None, Utc::now());
        cx.notify();
    });

    let tree = drawn(&shell, cx);
    assert!(
        tree.under(ids::SESSION_ROW_PREFIX).is_empty(),
        "another Project's Sessions leaked into an empty Project"
    );
    assert!(
        tree.find(&ids::project_tab(empty_project))
            .is_some_and(|project| project.selected),
        "the empty Project is not the selected capsule"
    );
    assert!(
        tree.contains(ids::SESSION_NEW),
        "an empty Project lost the control that starts its first Session"
    );
}

#[gpui::test]
fn the_terminal_dock_is_absent_until_it_is_opened(cx: &mut TestAppContext) {
    let (_state, shell, cx) = open(cx);
    assert!(
        !drawn(&shell, cx).contains(ids::TERMINAL_DOCK),
        "a dock nobody opened is in the tree"
    );

    cx.update(|window, cx| {
        shell.update(cx, |shell, cx| shell.toggle_terminal(window, cx));
    });
    let tree = drawn(&shell, cx);
    assert!(
        tree.contains(ids::TERMINAL_DOCK),
        "the dock is open and not in the tree; tree: {:?}",
        tree.ids()
    );
    assert!(tree.contains(ids::TERMINAL_BODY));
    assert!(tree.contains(ids::TERMINAL_COLLAPSE));
}

#[gpui::test]
fn the_diff_pane_is_absent_until_it_is_opened(cx: &mut TestAppContext) {
    let (_state, shell, cx) = open(cx);
    assert!(
        !drawn(&shell, cx).contains(ids::CHANGES),
        "a pane nobody opened is in the tree"
    );

    shell.update(cx, |shell, cx| shell.toggle_right_pane(cx));
    assert!(
        drawn(&shell, cx).contains(ids::CHANGES),
        "the diff pane is open and not in the tree"
    );
}

#[gpui::test]
fn the_session_down_banner_only_exists_while_the_session_is_stranded(cx: &mut TestAppContext) {
    let (state, shell, cx) = open(cx);
    let chat = state.read_with(cx, |state, _| {
        state.selected_chat.clone().expect("a session is selected")
    });
    assert!(!drawn(&shell, cx).contains(ids::SESSION_BANNER));

    state.update(cx, |state, cx| {
        state.set_session_failure(
            &chat,
            Some(SessionFailure {
                detail: Some("the agent process was killed by signal 9".into()),
            }),
        );
        cx.notify();
    });

    let tree = drawn(&shell, cx);
    let banner = tree
        .find(ids::SESSION_BANNER)
        .unwrap_or_else(|| panic!("the banner is up and not in the tree: {:?}", tree.ids()));
    assert_eq!(
        banner.text.as_deref(),
        Some("the agent process was killed by signal 9"),
        "the banner's id carries something other than what it says"
    );
    assert!(tree.contains(ids::SESSION_BANNER_RECOVER));

    state.update(cx, |state, cx| {
        state.set_session_failure(&chat, None);
        cx.notify();
    });
    let tree = drawn(&shell, cx);
    assert!(!tree.contains(ids::SESSION_BANNER));
    assert!(
        !tree.contains(ids::SESSION_BANNER_RECOVER),
        "the recover control outlived the banner it belongs to"
    );
}

#[gpui::test]
fn the_suggest_list_only_exists_while_a_slash_is_being_typed(cx: &mut TestAppContext) {
    let (state, shell, cx) = open(cx);
    let chat = state.read_with(cx, |state, _| {
        state.selected_chat.clone().expect("a session is selected")
    });
    state.update(cx, |state, cx| {
        state.set_session_commands(
            &chat,
            crate::viewmodel::SessionCommands {
                available: vec![crate::viewmodel::AgentCommand {
                    name: "compact".into(),
                    description: "Compact the conversation".into(),
                }],
            },
        );
        cx.notify();
    });
    assert!(
        !drawn(&shell, cx).contains(ids::SUGGEST_LIST),
        "a list nobody asked for is in the tree"
    );

    shell.update(cx, |shell, cx| {
        shell.composer.update(cx, |composer, cx| {
            composer
                .input
                .update(cx, |input, cx| input.set_text("/comp", cx));
        });
    });

    let tree = drawn(&shell, cx);
    assert!(
        tree.contains(ids::SUGGEST_LIST),
        "the list is on screen and not in the tree; tree: {:?}",
        tree.ids()
    );
    let rows = tree.under(ids::SUGGEST_ROW_PREFIX);
    assert!(!rows.is_empty(), "the list has rows the tree cannot see");
    assert_eq!(rows[0].id, ids::suggest_row(0));

    shell.update(cx, |shell, cx| {
        shell.composer.update(cx, |composer, cx| {
            composer
                .input
                .update(cx, |input, cx| input.set_text("", cx));
        });
    });
    let tree = drawn(&shell, cx);
    assert!(!tree.contains(ids::SUGGEST_LIST));
    assert!(
        tree.under(ids::SUGGEST_ROW_PREFIX).is_empty(),
        "rows of a dismissed list are still clickable through the tree"
    );
}

#[gpui::test]
fn the_frame_counter_moves_when_the_window_draws_again(cx: &mut TestAppContext) {
    let (_state, shell, cx) = open(cx);
    let before = shell.read_with(cx, |shell, _| shell.surface_generation());
    cx.update(|window, _| window.refresh());
    cx.run_until_parked();
    let after = shell.read_with(cx, |shell, _| shell.surface_generation());
    assert!(
        after > before,
        "a frame was drawn and the counter did not move ({before} → {after})"
    );
}

#[gpui::test]
fn the_boot_splash_is_in_the_tree_for_exactly_as_long_as_it_is_on_screen(cx: &mut TestAppContext) {
    let (_state, shell, cx) = open(cx);
    assert!(
        drawn(&shell, cx).contains(ids::SPLASH),
        "the splash is over the shell and a driver cannot tell"
    );

    // The splash holds for a beat and then crossfades; a driver waits it out by
    // watching the tree, and so does this.
    cx.background_executor
        .advance_clock(std::time::Duration::from_secs(5));
    let tree = drawn(&shell, cx);
    assert!(
        !tree.contains(ids::SPLASH),
        "the splash is gone from the window and still in the tree"
    );
    assert!(
        tree.contains(ids::COMPOSER_INPUT),
        "the shell underneath never arrived"
    );
}

#[gpui::test]
fn the_prompt_field_reports_what_it_holds(cx: &mut TestAppContext) {
    let (_state, shell, cx) = open(cx);
    let field = |cx: &mut VisualTestContext| {
        drawn(&shell, cx)
            .find(ids::COMPOSER_INPUT)
            .expect("the prompt field is on screen and not in the tree")
            .text
            .clone()
    };
    assert_eq!(field(cx).as_deref(), Some(""));

    shell.update(cx, |shell, cx| {
        shell.composer.update(cx, |composer, cx| {
            composer
                .input
                .update(cx, |input, cx| input.set_text("ship the port", cx));
        });
    });
    assert_eq!(
        field(cx).as_deref(),
        Some("ship the port"),
        "a driver reading the field back would not see what it typed"
    );
}

#[gpui::test]
fn a_refused_prompt_says_why_where_a_driver_can_read_it(cx: &mut TestAppContext) {
    let (_state, shell, cx) = open(cx);
    assert!(
        !drawn(&shell, cx).contains(ids::COMPOSER_NOTICE),
        "a composer that has refused nothing is already showing a refusal"
    );

    shell.update(cx, |shell, cx| {
        shell.composer.update(cx, |composer, cx| {
            composer.failure = Some("The agent is still working on the last turn.".into());
            cx.notify();
        });
    });
    assert_eq!(
        drawn(&shell, cx)
            .find(ids::COMPOSER_NOTICE)
            .expect("the refusal is on screen and not in the tree")
            .text
            .as_deref(),
        Some("The agent is still working on the last turn."),
        "a driver would see a prompt bounce with nothing to say why"
    );
}

#[gpui::test]
fn the_window_boots_on_the_settings_the_last_run_left_behind(cx: &mut TestAppContext) {
    let dir = tempfile::tempdir().expect("a scratch directory");
    let stored = crate::settings::UiSettings {
        sidebar_width: 320.0,
        sidebar_collapsed: true,
        terminal_height: 260.0,
        ..Default::default()
    };
    stored.save(dir.path()).expect("the settings were stored");

    let now = Utc::now();
    cx.update(install);
    let held = dir.path().to_path_buf();
    let state = cx.update(|cx| {
        cx.new(|_| {
            let mut state = crate::fixtures::shell_state(now);
            state.data_dir = Some(held);
            state
        })
    });
    let (shell, cx) = cx.add_window_view(move |_, cx| Shell::new(state, cx));

    shell.read_with(cx, |shell, _| {
        assert_eq!(shell.settings.sidebar_width, 320.0);
        assert!(
            shell.settings.sidebar_collapsed,
            "a sidebar the user closed came back open"
        );
        assert_eq!(shell.settings.terminal_height, 260.0);
    });
}

/// A machine with nothing registered yet: the canvas that invites a space is on
/// screen, is addressable, and focus is on it rather than on the composer this
/// window never drew.
///
/// The consequence of getting that wrong — every shortcut dead until something
/// is clicked — only shows on a real window: a test window re-homes focus when
/// the handle it was given was never rendered, so what guards it is the cold
/// start of `shell-spaces-smoke`, which cannot summon the palette at all.
#[gpui::test]
fn a_window_with_no_space_can_still_be_worked_from_the_keyboard(cx: &mut TestAppContext) {
    let (state, shell, cx) = open(cx);
    state.update(cx, |state, _| {
        state.spaces.clear();
        state.chats.clear();
        state.selected_chat = None;
    });
    let tree = drawn(&shell, cx);

    assert!(
        tree.contains(ids::ONBOARDING) && tree.contains(ids::ONBOARDING_ADD),
        "the only thing on screen is not in the tree; it holds {:?}",
        tree.ids()
    );
    assert!(
        !tree.contains(ids::COMPOSER_INPUT),
        "a window with nowhere to send a message drew a composer"
    );
    let focused = cx.update(|window, cx| window.focused(cx));
    let root = shell.read_with(cx, |shell, _| shell.focus_handle.clone());
    assert_eq!(
        focused.as_ref(),
        Some(&root),
        "focus went somewhere other than the one thing on screen, so on a real \
         window the shortcuts are dead until something is clicked"
    );

    cx.update(|window, cx| {
        let combo = crate::settings::platform_combo("mod-k");
        let stroke = gpui::Keystroke::parse(&combo).expect("add-space shortcut is a keystroke");
        window.dispatch_keystroke(stroke, cx);
    });
    cx.run_until_parked();
    let tree = drawn(&shell, cx);
    assert!(
        tree.contains(ids::ADD_SPACE),
        "the add-space shortcut opened nothing on a window that has only one thing to do; the tree holds {:?}",
        tree.ids()
    );
}

#[gpui::test]
fn the_rewind_pane_only_exists_while_a_rewind_is_being_decided(cx: &mut TestAppContext) {
    let (state, shell, cx) = open(cx);
    let chat = state.read_with(cx, |state, _| {
        state.selected_chat.clone().expect("a session is selected")
    });
    assert!(
        !drawn(&shell, cx).contains(ids::REWIND),
        "a pane nobody opened is in the tree"
    );

    state.update(cx, |state, cx| {
        state.set_session_checkpoints(
            &chat,
            crate::viewmodel::SessionCheckpoints {
                available: vec![crate::viewmodel::CheckpointMark {
                    entry_id: None,
                    prompt_index: 1,
                    file_snapshots: 2,
                    has_file_changes: true,
                    preview: Some("add the score".into()),
                }],
            },
        );
        cx.notify();
    });
    // A checkpoint the agent holds is not a decision anyone is making.
    assert!(
        !drawn(&shell, cx).contains(ids::REWIND),
        "listing a checkpoint opened a pane by itself"
    );

    shell.update(cx, |shell, cx| {
        shell.rewind.update(cx, |pane, cx| pane.open_at(1, cx));
    });

    let tree = drawn(&shell, cx);
    assert!(
        tree.contains(ids::REWIND),
        "the pane is open and not in the tree; tree: {:?}",
        tree.ids()
    );
    // The limit of the mechanism is on screen where the decision is made,
    // before anything has been picked.
    let coverage = tree
        .find(ids::REWIND_COVERAGE)
        .expect("the snapshot-coverage limit is not in the tree");
    let said = coverage.text.clone().unwrap_or_default();
    assert!(
        said.contains("only put back what the agent snapshotted"),
        "the coverage note does not state the limit: {said}"
    );
    // All three protocol modes, and no confirm control until a dry run has
    // been answered.
    assert_eq!(
        tree.under(ids::REWIND_MODE_PREFIX).len(),
        crate::viewmodel::RewindMode::ALL.len(),
        "the pane offers modes the tree cannot see"
    );
    assert!(
        !tree.contains(ids::REWIND_CONFIRM),
        "a rewind could be confirmed before the agent said what it would do"
    );
    assert!(!tree.contains(ids::REWIND_PREVIEW));

    shell.update(cx, |shell, cx| {
        shell.rewind.update(cx, |pane, cx| pane.close(cx));
    });
    assert!(
        !drawn(&shell, cx).contains(ids::REWIND),
        "the pane outlived the decision it was standing over"
    );
}

#[gpui::test]
fn what_a_rewind_did_stays_on_screen_after_the_pane_is_gone(cx: &mut TestAppContext) {
    let (state, shell, cx) = open(cx);
    let chat = state.read_with(cx, |state, _| {
        state.selected_chat.clone().expect("a session is selected")
    });
    assert!(
        !drawn(&shell, cx).contains(ids::REWIND_SETTLED),
        "a session that has never been rewound reports one"
    );

    state.update(cx, |state, cx| {
        state.set_session_rewind(
            &chat,
            Some(crate::viewmodel::SessionRewind {
                mode: crate::viewmodel::RewindMode::FilesOnly,
                prompt_index: 1,
                success: true,
                reverted_files: vec!["src/a.rs".into()],
                conflicts: vec![crate::viewmodel::RewindConflict {
                    path: "src/b.rs".into(),
                    conflict_type: "something_new_upstream".into(),
                }],
                prompt_text: None,
                error: None,
            }),
        );
        cx.notify();
    });

    let tree = drawn(&shell, cx);
    assert!(
        !tree.contains(ids::REWIND),
        "reading back a rewind opened the pane again"
    );
    let strip = tree
        .find(ids::REWIND_SETTLED)
        .expect("the log holds a rewind and the window says nothing about it");
    let said = strip.text.clone().unwrap_or_default();
    assert!(said.contains("src/a.rs"), "{said}");
    assert!(
        said.contains("something_new_upstream"),
        "the agent's own conflict type was not carried through: {said}"
    );
}
