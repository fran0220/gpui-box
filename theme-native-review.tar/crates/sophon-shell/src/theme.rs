//! Borrowed: C01 (Comet `crates/ui/src/theme.rs` at the pinned checkout).
//! See `docs/borrowings.md`.
//!
//! Compatibility view over the active gpui-kit theme.
//!
//! Colors are precomputed from an oklch-derived neutral scale (perceptually even
//! lightness steps; the same scale comet's Tailwind theme used) into gpui [`Hsla`].
//! Hairlines are white at low alpha so they read on any surface. **Numbers drive
//! layout, colors are paint**: layout constants live here as plain numbers and never
//! depend on which color is painted.
//!
//! The gpui-kit [`ThemeRegistry`] is the only token/theme authority. Existing
//! product surfaces keep reading this derived [`Global`] while Wave 1 proves
//! visual parity, avoiding a big-bang migration of surface code.

use gpui::{App, BorrowAppContext as _, Global, Hsla, SharedString, hsla};
use gpui_kit::theme::{Theme as GpuiKitTheme, ThemeRegistry};
use sophon_theme::{DEFAULT_APPEARANCE, DEFAULT_DENSITY};

/// Temporary shell-facing view of the active concrete product theme.
#[derive(Debug, Clone)]
pub struct Theme {
    // ---- paint: neutral surfaces (oklch chroma 0) ----
    /// Main-panel background sampled from the active shell: `#060606`.
    pub bg: Hsla,
    /// Panel / sidebar surface — one scale step up.
    pub surface: Hsla,
    /// Raised surface: popovers, dialogs, cards.
    pub surface_raised: Hsla,
    /// Hover wash for interactive rows/buttons (white, low alpha).
    pub element_hover: Hsla,
    /// Active/selected wash (white, slightly higher alpha).
    pub element_active: Hsla,
    /// Hairline border — white at low alpha.
    pub border: Hsla,
    /// Stronger border for focused/raised edges.
    pub border_strong: Hsla,

    // ---- paint: text ----
    /// Primary text.
    pub text: Hsla,
    /// Muted text: timestamps, secondary labels.
    pub text_muted: Hsla,
    /// Faint text: placeholders, disabled.
    pub text_faint: Hsla,

    // ---- paint: accents ----
    /// Accent — indigo (working indicator, links, selection tint).
    pub accent: Hsla,
    /// Stronger accent for fills.
    pub accent_strong: Hsla,
    /// Danger — red (errors, stop button).
    pub danger: Hsla,
    /// Warning — amber (offline notices, awaiting-input).
    pub warning: Hsla,

    // ---- fonts ----
    /// UI font family. gpui-kit registers its embedded Geist assets before
    /// this compatibility view is installed.
    pub font_sans: SharedString,
    /// Monospace family for code/terminal.
    pub font_mono: SharedString,
    /// Explicit system fallbacks, for callers that want to skip the lookup.
    pub font_sans_fallback: SharedString,
    pub font_mono_fallback: SharedString,
}

impl Theme {
    // ---- numbers drive layout (px) ----
    /// Frost translucency over the blurred window background (macOS vibrancy).
    /// Opaque elsewhere: Linux/Windows get no compositor-blur guarantee, and a
    /// merely transparent window would show raw desktop through the sidebar.
    /// Darkness matched by eye to a reference Electron app's dark glass. That
    /// scrim is 0.76 over `hsl(0 0% 3%)`, but it sits on Electron's
    /// `under-window` vibrancy MATERIAL, which pre-darkens the blur; our bare
    /// backdrop blur has no material layer, so the scrim runs heavier to land
    /// on the same perceived tone (see [`Theme::glass`]).
    pub const GLASS_ALPHA: f32 = if cfg!(target_os = "macos") { 0.90 } else { 1.0 };
    /// Main-panel header height (comet `h-11`) — in-card headers (changes pane).
    pub const HEADER_HEIGHT: f32 = 44.0;
    /// The unified window titlebar (traffic lights + cluster + tabs). Content
    /// rides [`Self::TITLEBAR_TOP_PAD`] lower than center so the air above
    /// matches the perceived gap to the inset card below (border + card body).
    pub const TITLEBAR_HEIGHT: f32 = 38.0;
    /// Downward shift of titlebar content within the bar.
    pub const TITLEBAR_TOP_PAD: f32 = 2.0;
    /// Reserved status strip under the content outlet (comet `h-6`) — the
    /// WorkingIndicator row; reserving it keeps the composer from shifting.
    pub const STATUS_STRIP_HEIGHT: f32 = 24.0;
    /// Message bubble corner radius.
    pub const BUBBLE_RADIUS: f32 = 16.0;
    /// Panel / card corner radius.
    pub const PANEL_RADIUS: f32 = 10.0;
    /// Small control radius (buttons, chips).
    pub const CONTROL_RADIUS: f32 = 6.0;
    /// Base spacing steps.
    pub const SPACE_XS: f32 = 4.0;
    pub const SPACE_SM: f32 = 8.0;
    pub const SPACE_MD: f32 = 12.0;
    pub const SPACE_LG: f32 = 16.0;

    /// The frost tint painted over the blurred window background (macOS
    /// glass). Darker than `surface` — matched to the reference dark
    /// vibrancy scrim: `hsl(0 0% 3%)` (#080808) at [`Self::GLASS_ALPHA`].
    /// On opaque platforms this IS the surface tone (no tint swap).
    pub fn glass(&self) -> Hsla {
        if Self::GLASS_ALPHA < 1.0 {
            grey(8).opacity(Self::GLASS_ALPHA)
        } else {
            self.surface
        }
    }

    /// Registers and activates Sophon's concrete theme documents, then updates
    /// the temporary shell compatibility global from the active gpui-kit theme.
    /// `gpui_kit::install(cx)` must run first at the application/test bootstrap.
    pub fn install(cx: &mut App) {
        let result = cx.update_global::<ThemeRegistry, Result<(), String>>(|registry, _| {
            sophon_theme::activate(registry, DEFAULT_APPEARANCE, DEFAULT_DENSITY)
        });
        result.expect("embedded Sophon themes must register and activate");
        let active = GpuiKitTheme::get(cx).clone();
        cx.set_global(Self::from_gpui_kit(&active));
    }

    /// Build the default compatibility view from Sophon's concrete dark
    /// TokenDocument. This remains for pure rendering tests and helpers that do
    /// not own an [`App`].
    pub fn dark() -> Self {
        let theme =
            GpuiKitTheme::from_tokens(sophon_theme::document(DEFAULT_APPEARANCE), DEFAULT_DENSITY);
        Self::from_gpui_kit(&theme)
    }

    fn from_gpui_kit(theme: &GpuiKitTheme) -> Self {
        Self {
            bg: theme.colors.canvas,
            surface: theme.colors.panel,
            surface_raised: theme.colors.raised,
            element_hover: theme.colors.hover,
            element_active: theme.colors.active,
            border: theme.colors.hairline,
            border_strong: theme.colors.hairline_strong,
            text: theme.colors.text,
            text_muted: theme.colors.text_muted,
            text_faint: theme.colors.text_faint,
            accent: theme.colors.accent,
            accent_strong: theme.colors.accent_strong,
            danger: theme.colors.danger,
            warning: theme.colors.warning,
            font_sans: theme.typography.sans.clone(),
            font_mono: theme.typography.mono.clone(),
            font_sans_fallback: theme.typography.sans_fallback.clone(),
            font_mono_fallback: theme.typography.mono_fallback.clone(),
        }
    }

    /// Read the theme global.
    pub fn of(cx: &App) -> &Theme {
        cx.global::<Theme>()
    }
}

impl Default for Theme {
    fn default() -> Self {
        Self::dark()
    }
}

// Transitional cache only: every field is derived from ThemeRegistry above.
// Product surfaces still require `&Theme`, so removing this Global belongs to
// the later surface migration, after visual parity is established.
impl Global for Theme {}

/// A neutral (chroma 0) oklch tone as Hsla. Chroma 0 means r == g == b exactly,
/// so this goes straight to an achromatic Hsla (skipping the hue math avoids
/// float-noise saturation).
pub fn neutral(lightness: f32) -> Hsla {
    let [v, _, _] = oklch_to_srgb(lightness, 0.0, 0.0);
    hsla(0.0, 0.0, v, 1.0)
}

/// Interactive-state wash: TRANSLUCENT soft-white, with alphas high enough to
/// stay visible at the brightest backdrop the 0.90 glass scrim can produce
/// (~L 0.13 over pure white — a 12% wash still adds ~+24 luma there). Fully
/// opaque washes killed the glass and flashed dark mid-fade (user reports);
/// hover fades must rest on `wash(0.0)`, never transparent BLACK, so the
/// interpolation stays white-toned.
pub fn wash(alpha: f32) -> Hsla {
    hsla(0.0, 0.0, 0.92, alpha)
}

/// White at the given alpha — the hairline/wash primitive.
pub fn white_alpha(alpha: f32) -> Hsla {
    hsla(0.0, 0.0, 1.0, alpha)
}

/// Selected-state glass treatment (Project capsules and Session rows): a
/// TRANSLUCENT wash the vibrancy reads through — heavier flat washes blocked
/// the glass (user request).
pub fn glass_selected_bg() -> Hsla {
    wash(0.14)
}

/// The selected chip's bright outline, as an INSET shadow: gpui paints inset
/// shadows ON TOP of the background, edges only — a border with zero layout
/// cost. Drop shadows are filled rects painted BEHIND the element, and behind
/// a 5% fill they showed straight through as an opaque dark plate with a
/// greyed ring (user report) — nothing may paint behind a glass chip.
pub fn glass_selected_shadows() -> Vec<gpui::BoxShadow> {
    vec![gpui::BoxShadow {
        color: white_alpha(0.09),
        offset: gpui::point(gpui::px(0.0), gpui::px(0.0)),
        blur_radius: gpui::px(0.0),
        spread_radius: gpui::px(1.0),
        inset: true,
    }]
}

/// An exact achromatic tone from an 8-bit channel value (`grey(13)` ≡ `#0d0d0d`)
/// — for surfaces matched against reference-screenshot samples.
pub fn grey(value: u8) -> Hsla {
    hsla(0.0, 0.0, value as f32 / 255.0, 1.0)
}

/// Convert an oklch color (CSS notation: L 0..1, C, H in degrees) to gpui Hsla.
pub fn oklch(l: f32, c: f32, h_deg: f32) -> Hsla {
    let [r, g, b] = oklch_to_srgb(l, c, h_deg);
    let (h, s, l) = rgb_to_hsl(r, g, b);
    hsla(h, s, l, 1.0)
}

/// oklch → sRGB (each 0..1, clamped/gamut-clipped per channel).
/// Reference: Björn Ottosson's OKLab definition (the same matrices CSS Color 4 uses).
pub(crate) fn oklch_to_srgb(l: f32, c: f32, h_deg: f32) -> [f32; 3] {
    let h = h_deg.to_radians();
    let a = c * h.cos();
    let b = c * h.sin();

    // OKLab → LMS (cube roots undone)
    let l_ = l + 0.396_337_78 * a + 0.215_803_76 * b;
    let m_ = l - 0.105_561_346 * a - 0.063_854_17 * b;
    let s_ = l - 0.089_484_18 * a - 1.291_485_5 * b;
    let (l3, m3, s3) = (l_ * l_ * l_, m_ * m_ * m_, s_ * s_ * s_);

    // LMS → linear sRGB
    let r = 4.076_741_7 * l3 - 3.307_711_6 * m3 + 0.230_969_93 * s3;
    let g = -1.268_438 * l3 + 2.609_757_4 * m3 - 0.341_319_4 * s3;
    let b = -0.004_196_086_3 * l3 - 0.703_418_6 * m3 + 1.707_614_7 * s3;

    [gamma_encode(r), gamma_encode(g), gamma_encode(b)]
}

fn gamma_encode(x: f32) -> f32 {
    let x = x.clamp(0.0, 1.0);
    if x <= 0.003_130_8 {
        12.92 * x
    } else {
        1.055 * x.powf(1.0 / 2.4) - 0.055
    }
}

/// sRGB (0..1 components) → HSL, all components 0..1 (gpui's Hsla convention).
pub(crate) fn rgb_to_hsl(r: f32, g: f32, b: f32) -> (f32, f32, f32) {
    let max = r.max(g).max(b);
    let min = r.min(g).min(b);
    let l = (max + min) / 2.0;
    let delta = max - min;
    if delta < f32::EPSILON {
        return (0.0, 0.0, l);
    }
    let s = if l > 0.5 {
        delta / (2.0 - max - min)
    } else {
        delta / (max + min)
    };
    let h = if (max - r).abs() < f32::EPSILON {
        ((g - b) / delta).rem_euclid(6.0)
    } else if (max - g).abs() < f32::EPSILON {
        (b - r) / delta + 2.0
    } else {
        (r - g) / delta + 4.0
    } / 6.0;
    (h, s, l)
}

/// Linear per-component mix of two colors (paint helper for the gradient spinner).
pub fn mix(a: Hsla, b: Hsla, t: f32) -> Hsla {
    let t = t.clamp(0.0, 1.0);
    let lerp = |x: f32, y: f32| x + (y - x) * t;
    // Mix through hue naively — both spinner endpoints sit close enough on the
    // wheel that shortest-arc handling isn't needed for our palette.
    hsla(
        lerp(a.h, b.h),
        lerp(a.s, b.s),
        lerp(a.l, b.l),
        lerp(a.a, b.a),
    )
}

#[cfg(test)]
mod tests {
    use std::sync::Arc;

    use gpui::{
        AnyWindowHandle, Context, HeadlessAppContext, Hsla, NoopTextSystem, Render, Rgba, Window,
        div, hsla, prelude::*, px, size,
    };
    use gpui_kit::semantics::{NodeSpec, Role, Semantic as _, SemanticRegistry};
    use gpui_kit::theme::Theme as GpuiKitTheme;
    use gpui_kit_testkit::{audit, capture::render_frame};
    use sophon_theme::{DEFAULT_APPEARANCE, DEFAULT_DENSITY};

    use super::{Theme, mix, oklch_to_srgb};

    fn srgb_u8(c: [f32; 3]) -> [u8; 3] {
        [
            (c[0] * 255.0).round() as u8,
            (c[1] * 255.0).round() as u8,
            (c[2] * 255.0).round() as u8,
        ]
    }

    fn rgba_u8(color: Hsla) -> [u8; 4] {
        let color = Rgba::from(color);
        [
            (color.r * 255.0).round() as u8,
            (color.g * 255.0).round() as u8,
            (color.b * 255.0).round() as u8,
            (color.a * 255.0).round() as u8,
        ]
    }

    #[test]
    fn neutral_950_is_0a0a0a() {
        // oklch(0.145 0 0) is Tailwind neutral-950, comet's app background.
        let rgb = srgb_u8(oklch_to_srgb(0.145, 0.0, 0.0));
        assert_eq!(rgb, [10, 10, 10]);
    }

    #[test]
    fn oklch_accents_match_reference() {
        // Reference values computed independently (CSS Color 4 matrices).
        assert_eq!(
            srgb_u8(oklch_to_srgb(0.673, 0.182, 276.935)),
            [124, 134, 255]
        ); // indigo-400
        assert_eq!(
            srgb_u8(oklch_to_srgb(0.704, 0.191, 22.216)),
            [255, 100, 103]
        ); // red-400
        assert_eq!(srgb_u8(oklch_to_srgb(0.828, 0.189, 84.429)), [255, 185, 0]); // amber-400
    }

    #[test]
    fn neutral_scale_is_ordered() {
        let t = Theme::dark();
        assert!(t.bg.l < t.surface.l);
        assert!(t.surface.l < t.surface_raised.l);
        assert!(t.surface_raised.l < t.text_faint.l);
        assert!(t.text_faint.l < t.text_muted.l);
        assert!(t.text_muted.l < t.text.l);
        // Monochrome: neutrals carry no saturation.
        for c in [
            t.bg,
            t.surface,
            t.surface_raised,
            t.text,
            t.text_muted,
            t.text_faint,
        ] {
            assert_eq!(c.s, 0.0);
            assert_eq!(c.a, 1.0);
        }
    }

    #[test]
    fn hairlines_are_white_and_washes_are_mid_grey() {
        let t = Theme::dark();
        // Hairlines stay white — they only need to read on dark surfaces.
        for c in [t.border, t.border_strong] {
            assert_eq!(c.l, 1.0, "hairlines are white");
            assert!(c.a > 0.0 && c.a < 0.25, "low alpha, got {}", c.a);
        }
        // Washes are translucent soft-white with enough alpha to read at the
        // glass scrim's brightness ceiling.
        for c in [t.element_hover, t.element_active] {
            assert!((c.l - 0.92).abs() < 0.002, "washes are soft-white");
            assert!(c.a >= 0.05 && c.a < 0.35, "alpha in band, got {}", c.a);
        }
        assert!(t.border.a < t.border_strong.a);
        // Hover intentionally equals the active fill (selection differs by
        // its ring, not brightness — user request).
        assert!(t.element_hover.a <= t.element_active.a);
    }

    #[test]
    fn accent_hues_land_in_their_bands() {
        let t = Theme::dark();
        // Hsla hue is 0..1 of the wheel. Indigo ≈ 230-250°, red < 15°, amber ≈ 40-55°.
        let deg = |c: Hsla| c.h * 360.0;
        assert!(
            (215.0..265.0).contains(&deg(t.accent)),
            "indigo hue {}",
            deg(t.accent)
        );
        assert!(
            deg(t.danger) < 15.0 || deg(t.danger) > 345.0,
            "red hue {}",
            deg(t.danger)
        );
        assert!(
            (35.0..60.0).contains(&deg(t.warning)),
            "amber hue {}",
            deg(t.warning)
        );
    }

    #[test]
    fn mix_endpoints_and_midpoint() {
        let a = hsla(0.0, 0.0, 0.0, 1.0);
        let b = hsla(0.5, 1.0, 1.0, 0.0);
        assert_eq!(mix(a, b, 0.0), a);
        assert_eq!(mix(a, b, 1.0), b);
        let mid = mix(a, b, 0.5);
        assert!((mid.l - 0.5).abs() < 1e-6 && (mid.a - 0.5).abs() < 1e-6);
        // Out-of-range t clamps.
        assert_eq!(mix(a, b, 2.0), b);
    }

    #[test]
    fn layout_numbers_match_comet() {
        assert_eq!(Theme::TITLEBAR_HEIGHT, 38.0);
        assert_eq!(Theme::TITLEBAR_TOP_PAD, 2.0);
        assert_eq!(Theme::HEADER_HEIGHT, 44.0); // h-11
        assert_eq!(Theme::STATUS_STRIP_HEIGHT, 24.0); // h-6
        assert_eq!(Theme::BUBBLE_RADIUS, 16.0);
        assert_eq!(Theme::PANEL_RADIUS, 10.0);
        assert_eq!(Theme::CONTROL_RADIUS, 6.0);
        assert_eq!(Theme::SPACE_XS, 4.0);
        assert_eq!(Theme::SPACE_SM, 8.0);
        assert_eq!(Theme::SPACE_MD, 12.0);
        assert_eq!(Theme::SPACE_LG, 16.0);
    }

    #[test]
    fn compatibility_view_copies_every_shell_semantic_from_gpui_kit() {
        let active =
            GpuiKitTheme::from_tokens(sophon_theme::document(DEFAULT_APPEARANCE), DEFAULT_DENSITY);
        let compat = Theme::from_gpui_kit(&active);
        assert_eq!(compat.bg, active.colors.canvas);
        assert_eq!(compat.surface, active.colors.panel);
        assert_eq!(compat.surface_raised, active.colors.raised);
        assert_eq!(compat.element_hover, active.colors.hover);
        assert_eq!(compat.element_active, active.colors.active);
        assert_eq!(compat.border, active.colors.hairline);
        assert_eq!(compat.border_strong, active.colors.hairline_strong);
        assert_eq!(compat.text, active.colors.text);
        assert_eq!(compat.text_muted, active.colors.text_muted);
        assert_eq!(compat.text_faint, active.colors.text_faint);
        assert_eq!(compat.accent, active.colors.accent);
        assert_eq!(compat.accent_strong, active.colors.accent_strong);
        assert_eq!(compat.danger, active.colors.danger);
        assert_eq!(compat.warning, active.colors.warning);
        assert_eq!(compat.font_sans, active.typography.sans);
        assert_eq!(compat.font_mono, active.typography.mono);
        assert_eq!(compat.font_sans_fallback, active.typography.sans_fallback);
        assert_eq!(compat.font_mono_fallback, active.typography.mono_fallback);
    }

    #[test]
    fn compatibility_view_preserves_the_historical_shell_paint_channels() {
        let theme = Theme::dark();
        assert_eq!(rgba_u8(theme.bg), [6, 6, 6, 255]);
        assert_eq!(rgba_u8(theme.surface), [13, 13, 13, 255]);
        assert_eq!(rgba_u8(theme.surface_raised), [30, 30, 30, 255]);
        assert_eq!(rgba_u8(theme.element_hover), [235, 235, 235, 36]);
        assert_eq!(rgba_u8(theme.element_active), [235, 235, 235, 41]);
        assert_eq!(rgba_u8(theme.border), [255, 255, 255, 20]);
        assert_eq!(rgba_u8(theme.border_strong), [255, 255, 255, 36]);
        assert_eq!(rgba_u8(theme.text), [229, 229, 229, 255]);
        assert_eq!(rgba_u8(theme.text_muted), [161, 161, 161, 255]);
        assert_eq!(rgba_u8(theme.text_faint), [115, 115, 115, 255]);
        assert_eq!(rgba_u8(theme.accent), [124, 134, 255, 255]);
        assert_eq!(rgba_u8(theme.accent_strong), [97, 95, 255, 255]);
        assert_eq!(rgba_u8(theme.danger), [255, 100, 103, 255]);
        assert_eq!(rgba_u8(theme.warning), [255, 185, 0, 255]);
        assert_eq!(theme.font_sans.as_ref(), "Geist");
        assert_eq!(theme.font_mono.as_ref(), "Geist Mono");
        if cfg!(target_os = "macos") {
            assert_eq!(theme.font_sans_fallback.as_ref(), "Helvetica");
            assert_eq!(theme.font_mono_fallback.as_ref(), "Menlo");
        } else if cfg!(target_os = "windows") {
            assert_eq!(theme.font_sans_fallback.as_ref(), "Segoe UI");
            assert_eq!(theme.font_mono_fallback.as_ref(), "Consolas");
        } else {
            assert_eq!(theme.font_sans_fallback.as_ref(), "DejaVu Sans");
            assert_eq!(theme.font_mono_fallback.as_ref(), "DejaVu Sans Mono");
        }
    }

    struct ThemeCanvas;

    impl Render for ThemeCanvas {
        fn render(&mut self, _window: &mut Window, cx: &mut Context<Self>) -> impl IntoElement {
            SemanticRegistry::global(cx).begin_frame();
            div().size_full().bg(Theme::of(cx).bg).semantic_in(
                cx,
                NodeSpec::new("theme.canvas", Role::Region).text("Theme canvas"),
            )
        }
    }

    #[test]
    fn installed_theme_paints_and_publishes_through_gpui_kit() {
        let mut cx = HeadlessAppContext::with_platform(
            Arc::new(NoopTextSystem),
            Arc::new(()),
            gpui_platform::current_headless_renderer,
        );
        cx.update(|cx| {
            gpui_kit::install(cx);
            Theme::install(cx);
        });
        let window: AnyWindowHandle = cx
            .open_window(size(px(64.0), px(64.0)), |_, cx| cx.new(|_| ThemeCanvas))
            .expect("headless theme window")
            .into();
        cx.run_until_parked();
        cx.update_window(window, |_, window, cx| window.draw(cx).clear(cx))
            .expect("draw headless theme window");

        let snapshot = cx.update(|cx| SemanticRegistry::global(cx).snapshot());
        assert!(
            audit(&snapshot).is_empty(),
            "theme canvas must publish an auditable semantic tree"
        );
        let canvas = snapshot.find("theme.canvas").expect("theme canvas node");
        assert!(canvas.visible);
        assert!(canvas.bounds.area() > 0.0);

        let frame = cx
            .update_window(window, |_, window, _| render_frame(window))
            .expect("headless theme window")
            .expect("deterministic GPUI frame");
        let center = ((frame.height / 2 * frame.width + frame.width / 2) * 4) as usize;
        assert_eq!(
            &frame.rgba[center..center + 4],
            &[6, 6, 6, 255],
            "the installed Sophon dark canvas must reach real GPUI paint"
        );
    }
}
