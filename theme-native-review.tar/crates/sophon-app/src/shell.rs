//! The product window: the ported Comet shell, opened at Comet's own geometry.
//!
//! Every window opened here is projected out of the running engine by
//! [`crate::shell_bridge`]: a cold start with no `--project` opens on the whole
//! registry the log holds, and `--project` opens on the registry with one
//! particular folder registered and worked in. The titlebar Project capsules
//! and active Project's sidebar Sessions therefore come from the log, down to
//! a registry that holds nothing — which opens empty rather than inventing one.
//!
//! [`sophon_shell::fixtures`] is still reachable, through `sophon shell-fixture`
//! and `sophon --fixture-shell`, and a window over it says so in its titlebar
//! ([`FIXTURE_NOTICE`]). That label is the whole point of keeping the two
//! apart: a reader must never have to guess whether a session on screen is
//! real, and a real session labelled as a fixture is the same lie the other way
//! round.
//!
//! There is no other shell. The previous Sophon shell has been deleted, so this
//! module is the only thing that puts a product window on screen.

use std::path::Path;
use std::sync::Arc;

use anyhow::{Context, Result};
use chrono::Utc;
use gpui::{App, AppContext as _, Bounds, TitlebarOptions, WindowBounds, WindowOptions, px, size};
use sophon_shell::placement::PlacementSink;
use sophon_shell::shell::Shell;
use sophon_shell::{fixtures, state::ShellState, theme::Theme};
use sophon_ui::Language;
use sophon_ui::projects::Projects as _;

/// What the titlebar says about where the rows on screen come from.
pub const FIXTURE_NOTICE: &str = "Fixture data";

/// What it says when the project is real but no agent can be started for it.
///
/// The sessions are the log's, the space is the project's, and there is no
/// runtime to open a conversation with — which is a different state from both
/// "fixtures" and "working", and is named as its own.
pub const NO_AGENT_NOTICE: &str = "No agent runtime";

/// Comet's window geometry (feature-inventory §1.1): 1320×880, min 900×600.
pub const DEFAULT_SIZE: (f32, f32) = (1320.0, 880.0);

/// Boot the app and open the shell on the registry. Blocks until the last
/// window closes.
///
/// No project was named, so none is registered and none is opened: the window
/// shows every project the log already holds and lands on the one it says was
/// worked in last. A log that holds none opens on an empty Project strip — there is
/// nothing to show, and showing something anyway is the one thing a cold start
/// may not do.
pub fn run(data_dir: &Path, size: (f32, f32), automation_port: Option<u16>) -> Result<()> {
    let settings = Arc::new(crate::agent_settings::AgentSettingsService::new(
        data_dir,
        tokio::runtime::Handle::current(),
    ));
    let specs = product_agent_specs(Arc::clone(&settings));
    let RegistryRuntime { host, workspace } = assemble_registry_with(data_dir, specs)?;

    let data_dir = data_dir.to_path_buf();
    let app = gpui_platform::application().with_assets(sophon_shell::icons::Assets);
    app.run(move |cx: &mut App| {
        boot(cx);
        let opened = open_registry_window_with_settings(&data_dir, workspace, settings, size, cx);
        serve_automation(automation_port, opened.window, cx);
        cx.activate(true);
    });

    host.shutdown();
    Ok(())
}

/// The same window over [`sophon_shell::fixtures`], for the surfaces that are
/// driven without a machine behind them.
///
/// Kept because a fixture world is the only way to drive the shell's own
/// surfaces — rows, tabs, menus, the dock — on a host with no account and no
/// agent binary. It is no longer what a plain `sophon` opens, and it says what
/// it is: [`FIXTURE_NOTICE`] stands in the titlebar for the whole run.
pub fn run_fixture(data_dir: &Path, size: (f32, f32), automation_port: Option<u16>) -> Result<()> {
    let data_dir = data_dir.to_path_buf();
    let app = gpui_platform::application().with_assets(sophon_shell::icons::Assets);
    app.run(move |cx: &mut App| {
        boot(cx);
        // The rows are fixtures; the window is not. Pointing the state at the
        // real data directory is what makes the pane widths, the collapse flags
        // and the keymap the user set here the ones they get back — the same
        // file, read at boot, that a window opened on a project reads.
        let state = cx.new(|_| {
            let mut state = fixtures::shell_state(Utc::now());
            state.data_dir = Some(data_dir.clone());
            state
        });
        let window = open_window_with(
            state,
            size,
            Some(FIXTURE_NOTICE),
            ShellWindowServices::default(),
            Some(sophon_ui::preferences::PreferencesFile::in_data_dir(
                &data_dir,
            )),
            cx,
        );
        serve_automation(automation_port, window, cx);
        cx.activate(true);
    });
    Ok(())
}

/// Puts the window on the automation port, when the caller asked for one.
///
/// A port that cannot be bound stops the process: a run launched to be driven
/// and left undriveable would otherwise sit there looking like a passing one
/// while every request went to whatever else holds the port.
#[cfg(any(debug_assertions, feature = "automation"))]
fn serve_automation(port: Option<u16>, window: gpui::WindowHandle<Shell>, cx: &mut App) {
    let Some(port) = port else {
        return;
    };
    match crate::shell_automation::serve(port, window, cx) {
        Ok(addr) => tracing::info!(%addr, "automation is listening"),
        Err(error) => {
            eprintln!("sophon: the automation port could not be bound: {error}");
            cx.quit();
        }
    }
}

#[cfg(not(any(debug_assertions, feature = "automation")))]
fn serve_automation(_port: Option<u16>, _window: gpui::WindowHandle<Shell>, _cx: &mut App) {}

/// The globals every shell window needs, in the order Comet sets them.
pub fn boot(cx: &mut App) {
    gpui_kit::install(cx);
    Theme::install(cx);
    sophon_shell::app_menus::init(cx);
    sophon_shell::shell::init(cx);
    // Without this macOS leaves `NSApp.mainMenu` nil: no app menu, no ⌘Q, and
    // nothing for the auto-hidden system menu bar to reveal.
    cx.set_menus(sophon_shell::app_menus::app_menus());
}

/// Boot the app on a real project and open the shell over the running engine.
///
/// Blocks until the last window closes. The engine is opened, the project is
/// registered the same way the dialog registers one, and the window is
/// projected out of the log by [`crate::shell_bridge`] — so the sessions on
/// screen exist because the log holds them.
///
/// An agent runtime that cannot be assembled (for example, no provider connection)
/// does not stop the window: the project and its sessions are still real, so
/// the shell opens saying it has no runtime rather than not opening at all.
/// The reason goes to the log, and every act then fails with the composer's
/// own "no runtime" notice instead of pretending to land.
pub fn run_project(
    data_dir: &Path,
    project: &Path,
    size: (f32, f32),
    automation_port: Option<u16>,
) -> Result<()> {
    let settings = Arc::new(crate::agent_settings::AgentSettingsService::new(
        data_dir,
        tokio::runtime::Handle::current(),
    ));
    let specs = product_agent_specs(Arc::clone(&settings));
    let ProjectRuntime {
        host,
        entry,
        workspace,
    } = assemble_under_with(data_dir, project, specs)?;

    let data_dir = data_dir.to_path_buf();
    let app = gpui_platform::application().with_assets(sophon_shell::icons::Assets);
    app.run(move |cx: &mut App| {
        boot(cx);
        let opened =
            open_project_window_with_settings(&data_dir, entry, workspace, settings, size, cx);
        serve_automation(automation_port, opened.window, cx);
        cx.activate(true);
    });

    host.shutdown();
    Ok(())
}

/// A project window's world, assembled but not yet on screen.
///
/// Held together so the window can be opened by something other than a cold
/// start without that caller re-deciding any of it: the engine, the registered
/// project and the runtime behind its sessions are one assembly, and a second
/// copy of it would be a second set of answers to the same questions.
#[derive(Debug)]
pub struct ProjectRuntime {
    /// The engine the window reads and writes through. Its owner is
    /// responsible for [`crate::host::Host::shutdown`] once the window is gone.
    pub host: crate::host::Host,
    /// The project as the log now holds it, registered by opening it.
    pub entry: sophon_ui::projects::ProjectEntry,
    /// Every registered project, with this one being worked in.
    pub workspace: Arc<crate::shell_bridge::Workspace>,
}

/// Opens the engine on `project` and puts an agent runtime behind its sessions.
///
/// An agent runtime that cannot be assembled (for example, no provider connection) is
/// reported as an absence rather than as a failure: the project and its
/// sessions are still real, and it is the caller who decides whether a window
/// without a runtime is worth opening.
pub fn assemble(data_dir: &Path, project: &Path) -> Result<ProjectRuntime> {
    let settings = Arc::new(crate::agent_settings::AgentSettingsService::new(
        data_dir,
        tokio::runtime::Handle::current(),
    ));
    let specs = product_agent_specs(Arc::clone(&settings));
    assemble_under_with(data_dir, project, specs)
}

fn assemble_under_with(
    data_dir: &Path,
    project: &Path,
    specs: Arc<crate::shell_bridge::workspace::SpecFor>,
) -> Result<ProjectRuntime> {
    let (host, projects) = open_engine(data_dir)?;
    let entry = projects
        .open(project)
        .map_err(|problem| anyhow::anyhow!(problem.message(Language::En)))
        .with_context(|| format!("could not open {}", project.display()))?;

    let workspace = crate::shell_bridge::Workspace::opened_on(
        projects as Arc<dyn sophon_ui::projects::Projects>,
        crate::shell_bridge::EngineProjectSessions::new(
            host.engine.clone(),
            tokio::runtime::Handle::current(),
            specs,
        ),
        Language::En,
        &entry,
    );

    Ok(ProjectRuntime {
        host,
        entry,
        workspace,
    })
}

/// The registry's world, assembled but not yet on screen.
///
/// The same parts as a [`ProjectRuntime`] minus the one thing a cold start with
/// no `--project` does not have: a project it was told to register. Which
/// project is being worked in is the log's answer, not the command line's.
#[derive(Debug)]
pub struct RegistryRuntime {
    /// The engine the window reads and writes through. Its owner is
    /// responsible for [`crate::host::Host::shutdown`] once the window is gone.
    pub host: crate::host::Host,
    /// Every registered project, on the one the log says was opened last.
    pub workspace: Arc<crate::shell_bridge::Workspace>,
}

/// Opens the engine on the registry, registering nothing and opening nothing.
///
/// Nothing is committed here: a cold start that recorded an open would move a
/// project to the front of the recent list for having been looked at, and the
/// list would then say the reader worked in it when they only started the app.
pub fn assemble_registry(data_dir: &Path) -> Result<RegistryRuntime> {
    let settings = Arc::new(crate::agent_settings::AgentSettingsService::new(
        data_dir,
        tokio::runtime::Handle::current(),
    ));
    let specs = product_agent_specs(Arc::clone(&settings));
    assemble_registry_with(data_dir, specs)
}

fn assemble_registry_with(
    data_dir: &Path,
    specs: Arc<crate::shell_bridge::workspace::SpecFor>,
) -> Result<RegistryRuntime> {
    let (host, projects) = open_engine(data_dir)?;
    let workspace = crate::shell_bridge::Workspace::on_the_registry(
        projects as Arc<dyn sophon_ui::projects::Projects>,
        crate::shell_bridge::EngineProjectSessions::new(
            host.engine.clone(),
            tokio::runtime::Handle::current(),
            specs,
        ),
        Language::En,
    );
    Ok(RegistryRuntime { host, workspace })
}

/// The engine and the registry over it, which every window needs and neither
/// of the two assemblies decides differently.
pub(crate) fn open_engine(
    data_dir: &Path,
) -> Result<(crate::host::Host, Arc<crate::projects::EngineProjects>)> {
    let host = crate::host::Host::open(data_dir)
        .context("could not open the host for the shell window")?;
    let projects = Arc::new(crate::projects::EngineProjects::new(
        host.engine.clone(),
        tokio::runtime::Handle::current(),
    ));
    Ok((host, projects))
}

/// A project window, and the two ends of it a caller can hold.
#[derive(Debug)]
pub struct ProjectWindow {
    /// Everything on screen is read out of here.
    pub state: gpui::Entity<ShellState>,
    /// Everything the window does leaves through here. `None` for a window
    /// opened without a runtime.
    pub host: Option<Arc<dyn sophon_shell::host::ShellHost>>,
    pub window: gpui::WindowHandle<Shell>,
}

/// Projects the assembled project into a fresh state and opens the window on it.
pub fn open_project_window(
    data_dir: &Path,
    entry: sophon_ui::projects::ProjectEntry,
    workspace: Arc<crate::shell_bridge::Workspace>,
    size: (f32, f32),
    cx: &mut App,
) -> ProjectWindow {
    let settings = Arc::new(crate::agent_settings::AgentSettingsService::new(
        data_dir,
        tokio::runtime::Handle::current(),
    ));
    open_project_window_with_settings(data_dir, entry, workspace, settings, size, cx)
}

fn open_project_window_with_settings(
    data_dir: &Path,
    entry: sophon_ui::projects::ProjectEntry,
    workspace: Arc<crate::shell_bridge::Workspace>,
    agent_settings: Arc<crate::agent_settings::AgentSettingsService>,
    size: (f32, f32),
    cx: &mut App,
) -> ProjectWindow {
    let device = crate::shell_bridge::local_device();
    // A window open on a project has a machine and a folder, which is
    // everything a shell needs; the fixture window has neither and keeps its
    // recording.
    let terminals = crate::shell_bridge::PtyTerminals::login_shell(entry.path.clone());
    let state = cx.new(|_| {
        let mut state = ShellState::new(vec![device.clone()], Vec::new(), Vec::new(), Vec::new());
        state.data_dir = Some(data_dir.to_path_buf());
        state
    });
    match workspace.active_sessions() {
        Some(_) => {
            let shell_host =
                crate::shell_bridge::attach(workspace, device, state.clone(), Language::En, cx);
            let window = open_window_with(
                state.clone(),
                size,
                None,
                ShellWindowServices {
                    host: Some(Arc::clone(&shell_host) as Arc<dyn sophon_shell::host::ShellHost>),
                    terminals: Some(terminals),
                    agent_settings: Some(agent_settings.clone()),
                },
                Some(sophon_ui::preferences::PreferencesFile::in_data_dir(
                    data_dir,
                )),
                cx,
            );
            ProjectWindow {
                state,
                host: Some(shell_host),
                window,
            }
        }
        None => {
            // The projects and the sessions the log holds for them are still
            // facts; only the runtime is missing, and the titlebar says which.
            // One frame and no loop: without a runtime nothing here can commit
            // anything, so there is nothing for a projection to notice.
            let rows = crate::shell_bridge::attach::frame(workspace.as_ref(), &device);
            state.update(cx, |state, cx| {
                crate::shell_bridge::apply(state, rows, crate::shell_bridge::Showing::nothing());
                cx.notify();
            });
            let window = open_window_with(
                state.clone(),
                size,
                Some(NO_AGENT_NOTICE),
                ShellWindowServices {
                    terminals: Some(terminals),
                    agent_settings: Some(agent_settings),
                    ..Default::default()
                },
                Some(sophon_ui::preferences::PreferencesFile::in_data_dir(
                    data_dir,
                )),
                cx,
            );
            ProjectWindow {
                state,
                host: None,
                window,
            }
        }
    }
}

/// Projects the registry into a fresh state and opens the window on it.
///
/// The write side is installed whatever the registry holds, which is the
/// difference from [`open_project_window`]: a window with no project — or with
/// one whose runtime would not start — still has to be able to browse the disk
/// and take a folder as a space, and every act that does need an agent is
/// refused by [`crate::shell_bridge::EngineHost`] in the runtime's own words at
/// the moment it is asked for.
pub fn open_registry_window(
    data_dir: &Path,
    workspace: Arc<crate::shell_bridge::Workspace>,
    size: (f32, f32),
    cx: &mut App,
) -> ProjectWindow {
    let settings = Arc::new(crate::agent_settings::AgentSettingsService::new(
        data_dir,
        tokio::runtime::Handle::current(),
    ));
    open_registry_window_with_settings(data_dir, workspace, settings, size, cx)
}

fn open_registry_window_with_settings(
    data_dir: &Path,
    workspace: Arc<crate::shell_bridge::Workspace>,
    agent_settings: Arc<crate::agent_settings::AgentSettingsService>,
    size: (f32, f32),
    cx: &mut App,
) -> ProjectWindow {
    let device = crate::shell_bridge::local_device();
    let active = workspace.active_project();
    let notice = standing_notice(active.is_some(), workspace.active_sessions().is_some());
    // A shell opens a terminal in a folder, and a window on no project has no
    // folder to open one in. Absent rather than guessed at: a dock that opened
    // on the home directory would be a shell in a place nobody chose.
    let terminals = active.as_ref().map(|entry| {
        crate::shell_bridge::PtyTerminals::login_shell(entry.path.clone())
            as Arc<dyn sophon_shell::terminal::host::TerminalHost>
    });
    let state = cx.new(|_| {
        let mut state = ShellState::new(vec![device.clone()], Vec::new(), Vec::new(), Vec::new());
        state.data_dir = Some(data_dir.to_path_buf());
        state
    });
    let shell_host =
        crate::shell_bridge::attach(workspace, device, state.clone(), Language::En, cx);
    let window = open_window_with(
        state.clone(),
        size,
        notice,
        ShellWindowServices {
            host: Some(Arc::clone(&shell_host) as Arc<dyn sophon_shell::host::ShellHost>),
            terminals,
            agent_settings: Some(agent_settings),
        },
        Some(sophon_ui::preferences::PreferencesFile::in_data_dir(
            data_dir,
        )),
        cx,
    );
    ProjectWindow {
        state,
        host: Some(shell_host),
        window,
    }
}

/// What the titlebar of a real window says, standing, about what is behind it.
///
/// A project being worked in with no runtime is named explicitly; otherwise
/// there is nothing to declare. [`FIXTURE_NOTICE`] is deliberately unreachable
/// here — the rows of any window this labels came out of the log.
fn standing_notice(on_project: bool, has_runtime: bool) -> Option<&'static str> {
    if on_project && !has_runtime {
        // The narrower fact wins: a borrowed login that produced no runtime is
        // not what a reader needs to be told about the project on screen.
        return Some(NO_AGENT_NOTICE);
    }
    None
}

/// How any project of this window gets an agent runtime.
///
/// Every part of it is required: a provider connection and the shared native Grok runtime. A
/// half-configured runtime is refused rather than started.
///
/// A closure rather than a call, because which projects a window will end up
/// holding is not known when it is assembled: the reader can add one at any
/// time, and every one of them gets its agent on exactly these terms.
/// Product runtime assembly. Settings are read when a project opens to fail
/// honestly if the selected source is unavailable, then again when each new
/// conversation first starts a native session. The resulting SessionSpec is immutable,
/// so crash recovery cannot switch a conversation to a different account.
fn product_agent_specs(
    settings: Arc<crate::agent_settings::AgentSettingsService>,
) -> Arc<crate::shell_bridge::workspace::SpecFor> {
    Arc::new(move |entry: &sophon_ui::projects::ProjectEntry| {
        let workspace = entry.path.clone();
        settings.process_settings_for(&workspace)?;
        let process_settings = {
            let settings = Arc::clone(&settings);
            let workspace = workspace.clone();
            Arc::new(move || settings.process_settings_for(&workspace))
                as Arc<
                    dyn Fn() -> Result<crate::agent_settings::ProcessSettings, String>
                        + Send
                        + Sync,
                >
        };
        Ok(crate::sessions::ProjectSpec {
            project_id: sophon_rpc::ProjectId::new(entry.id.clone()),
            agent_id: sophon_rpc::AgentId::new(entry.id.clone()),
            workspace,
            process_settings,
        })
    })
}

/// Open the shell window: frameless inset chrome with the traffic lights at
/// {14,14}, an app-owned titlebar drag region, and — on macOS — a blurred
/// window background so the shell's frost surface reads as glass.
pub fn open_window(
    state: gpui::Entity<ShellState>,
    size: (f32, f32),
    cx: &mut App,
) -> gpui::WindowHandle<Shell> {
    open_window_with(
        state,
        size,
        Some(FIXTURE_NOTICE),
        ShellWindowServices::default(),
        None,
        cx,
    )
}

#[derive(Default)]
struct ShellWindowServices {
    host: Option<Arc<dyn sophon_shell::host::ShellHost>>,
    terminals: Option<Arc<dyn sophon_shell::terminal::host::TerminalHost>>,
    agent_settings: Option<Arc<crate::agent_settings::AgentSettingsService>>,
}

/// The same window, told where its rows come from and what its acts leave
/// through. `notice` is the standing titlebar label — `None` for a window whose
/// data is real — `host` the runtime, absent for a window with none, and
/// `terminals` what the dock opens shells on, absent for a window with no
/// project to open one in.
fn open_window_with(
    state: gpui::Entity<ShellState>,
    (width, height): (f32, f32),
    notice: Option<&'static str>,
    services: ShellWindowServices,
    preferences: Option<sophon_ui::preferences::PreferencesFile>,
    cx: &mut App,
) -> gpui::WindowHandle<Shell> {
    let ShellWindowServices {
        host,
        terminals,
        agent_settings,
    } = services;
    let centred = Bounds::centered(None, size(px(width), px(height)), cx);
    let (bounds, restored) =
        crate::shell_placement::opening_bounds(preferences.as_ref(), centred, cx);
    let remembering = preferences
        .map(crate::shell_placement::RememberedPlacement::to_file)
        .map(Arc::new);
    let handle = cx
        .open_window(
            WindowOptions {
                window_bounds: Some(WindowBounds::Windowed(bounds)),
                window_min_size: Some(size(px(900.), px(600.))),
                titlebar: Some(TitlebarOptions {
                    title: None,
                    appears_transparent: true,
                    traffic_light_position: Some(gpui::point(px(14.), px(14.))),
                }),
                // The shell's own titlebar strip drags the window
                // (`WindowControlArea::Drag` + `start_window_move`) — mark the
                // content view app-owned so AppKit neither dead-zones the strip nor
                // delays its clicks.
                app_owns_titlebar_drag: true,
                // Frosted shell (macOS): blur the desktop behind the window.
                // Elsewhere blur support is compositor roulette — stay opaque.
                window_background: if cfg!(target_os = "macos") {
                    gpui::WindowBackgroundAppearance::Blurred
                } else {
                    gpui::WindowBackgroundAppearance::Opaque
                },
                app_id: Some("sophon".into()),
                ..Default::default()
            },
            move |_window, cx| {
                cx.new(|cx| {
                    let mut shell = Shell::new(state, cx);
                    if let Some(notice) = notice {
                        shell = shell.with_data_notice(notice);
                    }
                    if let Some(host) = host {
                        shell = shell.with_host(host, cx);
                    }
                    if let Some(settings) = agent_settings {
                        shell = shell.with_agent_settings_host(settings);
                    }
                    if let Some(terminals) = terminals {
                        shell = shell.with_terminal_host(terminals);
                    }
                    if let Some(remembering) = remembering {
                        shell = shell.reporting_placement_to(remembering as Arc<dyn PlacementSink>);
                    }
                    shell
                })
            },
        )
        .expect("failed to open the shell window");

    // The platform's best effort at the opening bounds is approximate — macOS
    // reads them as a content rectangle and reports them back as a frame — so a
    // restored window is put exactly where it was through the same conversion
    // that stored it, and only when it did not already land there. A window
    // that opened where it was asked to has nothing to correct, and moving it
    // anyway would be a move the user never made.
    if let Some(bounds) = restored {
        let _ = handle.update(cx, |_, window, _| {
            if sophon_ui::placement::WindowPlacement::new(window.bounds(), None)
                .differs_from(&sophon_ui::placement::WindowPlacement::new(bounds, None))
                && let Err(error) = sophon_ui::placement::apply(window, bounds)
            {
                tracing::debug!(%error, "the window could not be put back where it was");
            }
        });
    }
    handle
}

/// Keeps the deck bound to the project actually shown by the shell. Discovery
/// runs off the UI thread; an answer is installed only if the exact project id
/// is still active, and switching clears old views immediately so stale
/// supervision authority cannot survive while the new list is in flight.
#[cfg(test)]
mod tests {
    use gpui::TestAppContext;
    use gpui_kit::theme::{Density, ThemeRegistry};
    use sophon_shell::theme::Theme;

    use super::{FIXTURE_NOTICE, NO_AGENT_NOTICE, boot, standing_notice};

    #[gpui::test]
    fn production_boot_activates_sophon_before_installing_the_shell_view(cx: &mut TestAppContext) {
        cx.update(boot);
        assert!(cx.has_global::<ThemeRegistry>());
        assert!(cx.has_global::<Theme>());
        cx.read_global::<ThemeRegistry, _>(|registry, cx| {
            assert_eq!(registry.active().id.as_ref(), "sophon-dark");
            assert_eq!(registry.density(), Density::Comfortable);
            let shell = Theme::of(cx);
            assert_eq!(shell.bg, registry.active().colors.canvas);
            assert_eq!(shell.surface, registry.active().colors.panel);
            assert_eq!(shell.text, registry.active().colors.text);
            assert_eq!(shell.font_sans, registry.active().typography.sans);
        });
    }

    /// The one label that may never stand over rows read out of the log.
    #[test]
    fn a_window_over_the_log_never_calls_its_rows_fixtures() {
        for on_project in [false, true] {
            for has_runtime in [false, true] {
                assert_ne!(
                    standing_notice(on_project, has_runtime),
                    Some(FIXTURE_NOTICE),
                    "a real window labelled itself a fixture at \
                     ({on_project}, {has_runtime})"
                );
            }
        }
    }

    #[test]
    fn a_registry_with_nothing_being_worked_in_has_nothing_to_declare() {
        assert_eq!(standing_notice(false, false), None);
    }

    #[test]
    fn a_project_with_no_agent_behind_it_is_named_as_unavailable() {
        assert_eq!(standing_notice(true, false), Some(NO_AGENT_NOTICE));
    }
}
