# Sophon

**One agent, every kind of work.**

Sophon is a general-purpose native AI agent desktop for macOS, Windows, and
Linux. It is a Rust + GPUI application that statically links the public
[`grok-build-sdk`](https://github.com/fran0220/grok-build-sdk). It is not an
IDE or a product for one domain; domain products belong in future plugins.

This README is the architecture authority. [`PLAN.md`](PLAN.md) is the only
execution-status document. Detailed source/license attribution remains in the
non-design [provenance ledger](docs/borrowings.md).

## Current status

The Rust baseline provides the native shell, durable Project/Thread/Turn state,
an embedded SDK Runtime, local process and Git workflows, and semantic UI
automation. Provider Connections, Harness Evolution, persistent agent
orchestration, and the public Plugin ABI are planned, not shipped.

## Architecture

```text
sophon process
├─ GPUI presentation
├─ logical Host                     durable product control plane
│  ├─ Project / Thread / Turn
│  ├─ harness revisions and audit
│  ├─ credentials, plugins, Git and UI projections
│  └─ runtime/session reconciliation
└─ one shared grok-build-sdk Runtime
   ├─ Session ↔ Thread A
   ├─ Session ↔ Thread B
   └─ Session ↔ Thread C
```

The Host is a logical module in the desktop process, not a daemon and not a
second agent runtime. It remains because product identity, SQLite history,
idempotency, credentials, Git rewind, plugins and UI state must survive and be
queryable independently of opaque SDK session files. A daemon is considered
only if autonomous work must survive application termination or multiple
clients must attach concurrently.

### One shared Runtime, many Sessions

Sophon uses one application-owned SDK `Runtime` and one native SDK `Session`
per Sophon Thread. Different Projects share the Runtime; their durable facts,
workspace roots, harness snapshots and Session IDs remain distinct.

This is the default because:

- the SDK intentionally supports concurrent Sessions with different `cwd`,
  models and reasoning settings;
- Projects run with the same OS-user authority and are not security domains;
- each Runtime adds a worker thread, async executor, buffers, journals and
  recovery coordination;
- the current implementation already shares one Runtime;
- duplicating Runtime instances only to work around a coarse SDK API would
  bake an implementation limitation into the product architecture.

The pinned SDK currently makes provider catalogs, storage roots, skill/plugin
paths, MCP definitions, agent-service routing and the host delegate
Runtime-global. For v1 those are application-level inputs. Project-specific
harness, agent and tool behavior must cross a neutral immutable
Session/Turn-scoped SDK contract; if the public SDK cannot express that, the
SDK is extended rather than creating a Runtime per Project.

Multiple Runtime instances are not forbidden forever, but they require an
observed need for independent trust, failure, configuration or background
lifecycle domains. If that need appears, add a bounded Runtime pool with an
explicit policy instead of making Project identity imply Runtime identity.

### Ownership boundary

| Logical Host owns | `grok-build-sdk` owns |
|---|---|
| Durable product identities and revision history | Model/provider/tool loop |
| Harness entries, evidence, activation and rollback | Harness validation/materialization and refinement execution |
| Goals, schedules, budgets and user-visible policy | Continuation, gates, child-agent and kernel execution |
| OS keychain and loopback connection relay | Provider streaming through relay bearers |
| Git checkpoint/diff/rewind and long-term audit | Session recovery, compaction, retries and execution receipts |
| Plugin lifecycle and all UI projections | Native tools, MCP, skills, agents and hooks |

There is no transaction spanning SQLite, SDK recovery state, model calls,
tools or the filesystem. Cross-boundary work uses durable intent, idempotency
IDs, sequenced events, receipts and reconciliation. Uncertain external side
effects are surfaced, never silently replayed as exactly once.

### Harness Evolution

Sophon will be the sole source of truth for mutable prompt notes, memories,
skills, agent specifications, evidence and revisions. At a Turn boundary it
resolves baseline, Project and future plugin contributions into an immutable,
content-addressed `HarnessSnapshot`. The SDK validates/materializes the
snapshot and binds its canonical digest to the Turn and settlement receipt.

The SDK may cache immutable snapshots and own opaque recovery state, but it may
not maintain a second mutable harness store. A model-visible refiner returns a
typed patch against a base digest; the Host decides whether to commit and
activate it. Mid-Turn changes apply only to the next Turn. Conversation rewind
and harness rollback are separate operations.

## Non-negotiables

- `grok-build-sdk` is the only agent runtime implementation and is linked
  in-process. No runtime registry, external agent executable or product ACP
  seam.
- Execution is unrestricted with the OS user's authority. No user-facing
  permission, approval, grant, trust-tier, sandbox or protected-path system.
- Raw provider credentials live only in the OS keychain. The Runtime receives
  loopback relay bearers; plugin/helper/kernel processes receive no provider
  credentials, and snapshots/audit/export never contain them.
- The baseline owns every pixel. Plugins contribute versioned data; a WebView
  is a baseline surface, not an escape hatch.
- Public Plugin, UI, Connection and harness-bundle contracts evolve additively;
  breaking changes require a major version and migration path.
- Schema and protocol names are domain-neutral and never use the product name.
- Baseline, Project and future plugin content enter one SDK harness pipeline;
  plugins never add another model loop, mutable harness store or tool protocol.

## UI contract

`tokens/tokens.json` contains the concrete product token documents.
`sophon-theme` parses them through the pinned gpui-kit token contract and
registers the product themes without generating or mirroring a second Rust
schema. The pinned Comet source registered in the provenance ledger is the
visual and microinteraction reference; t3code is behavioral, not visual,
authority. Presentation reads view models, emits actions and owns only
transient visual state—it does not read SQLite, credentials or the Runtime.

Every operation must be keyboard reachable and expose truthful semantic state.
UI changes require gpui-kit-testkit semantic and visual coverage, with native
macOS/Windows evidence for platform-specific claims.

## Workspace

| Crate | Responsibility |
|---|---|
| `sophon-rpc` | Commands, events, projections and identifiers |
| `sophon-store` | SQLite event log and projection persistence |
| `sophon-core` | Deciders, projectors, ordering and recovery |
| `sophon-process` | Cross-platform child process-tree lifecycle |
| `sophon-vcs` | Host-owned Git checkpoints, diffs and rewind |
| `sophon-client` | Nonvisual projections and connection supervision |
| `sophon-ui` | Product projections, preferences and automation |
| `sophon-shell` | GPUI shell, transcript, composer, terminal and settings |
| `sophon-theme` | Concrete token registration and platform adaptation |
| `sophon-app` | Composition root and `sophon` binary |

## Development

`Cargo.lock` and `rust-toolchain.toml` are authoritative for pinned build
inputs. The lifecycle configuration provisions the required sibling GPUI fork
at `../origingame-refs/zed-fork`.

Repository gate:

```bash
cargo check --workspace && cargo test --workspace && cargo clippy --workspace --all-targets && cargo fmt --all --check
```

The Linux Orb is the Cargo/headless baseline. Platform claims require an
online native macOS or Windows runner; Linux results do not substitute for
either. Normal builds and tests require no project secrets or `.env` files.

“Sophon” remains a working name pending availability and trademark checks. The
intended repository license is Apache-2.0, subject to release closure.
